#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [////            ]");
    fflush(stdout);
    sleep(2);
    system("clear");
    system("clear");
    
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [////////////    ]");
    fflush(stdout);
    sleep(2);
    system("clear");
    
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [////////////////]");
    fflush(stdout);
    sleep(2);
    

    
    
 
    


    return 0;
}