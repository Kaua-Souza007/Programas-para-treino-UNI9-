#include <stdio.h>
#include <string.h>

struct Pedido {
    char cliente[50];
    char produto[50];
    int quantidade;
    float preco;
};

int main() {

    struct Pedido pedidos[10];
    int totalPedidos = 0;
    int opcao;
    do {
        printf("\n====== ATLAS WEAR ======\n");
        printf("1 - Novo Pedido\n");
        printf("2 - Listar Pedidos\n");
        printf("3 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);
        getchar();

        switch(opcao) {

            case 1:
                printf("\n--- Novo Pedido ---\n");

                printf("Nome do cliente: ");
                fgets(pedidos[totalPedidos].cliente, 50, stdin);
                pedidos[totalPedidos].cliente[strcspn(pedidos[totalPedidos].cliente, "\n")] = 0;

                printf("Produto (Camiseta / Moletom / Tenis): ");
                fgets(pedidos[totalPedidos].produto, 50, stdin);
                pedidos[totalPedidos].produto[strcspn(pedidos[totalPedidos].produto, "\n")] = 0;

                printf("Quantidade: ");
                scanf("%d", &pedidos[totalPedidos].quantidade);

                printf("Preco unitario: ");
                scanf("%f", &pedidos[totalPedidos].preco);
                getchar();

                totalPedidos++;

                printf("\n✅ Pedido registrado!\n");
                break;

            case 2:
                printf("\n📋 Lista de Pedidos:\n");

                for(int i = 0; i < totalPedidos; i++) {
                    float total = pedidos[i].quantidade * pedidos[i].preco;

                    printf("\nPedido %d\n", i + 1);
                    printf("Cliente: %s\n", pedidos[i].cliente);
                    printf("Produto: %s\n", pedidos[i].produto);
                    printf("Quantidade: %d\n", pedidos[i].quantidade);
                    printf("Preco: R$ %.2f\n", pedidos[i].preco);
                    printf("Total: R$ %.2f\n", total);
                }
                break;

            case 3:
                printf("\nEncerrando sistema...\n");
                break;

            default:
                printf("\nOpcao invalida!\n");
        }

    } while(opcao != 3);

    return 0;
}