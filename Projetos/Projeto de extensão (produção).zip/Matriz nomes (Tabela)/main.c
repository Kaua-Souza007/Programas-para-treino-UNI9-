#include <stdio.h>

int main() {

    char nomes[3][20];

    for(int i = 0; i < 3; i++) {
        printf("Digite um nome: ");
        fgets(nomes[i], 20, stdin);
    }

    printf("\nLista:\n");

    for(int i = 0; i < 3; i++) {
        printf("%s", nomes[i]);
    }

    return 0;
}