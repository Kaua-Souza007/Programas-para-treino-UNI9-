#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

int main() {
    
    int m = -2, n = 0;
    
    printf("\n\n                                       ATLAS WEAR\n");
    
    if (n <= 49) {
        
    printf("                                       Carregando...\n");
        
    }
    
    else {
    printf("\n\nPronto!\n");
    }


    for(int i = 0; i <= 50; i++) {
    m = (m + 2);
    n++;
    
        printf("\r                  [");
        
        for(int j = 0; j < i; j++) {
            printf("/");
        }
        
        

        printf("] %d%%", m);
        fflush(stdout);

        #ifdef _WIN32
            Sleep(30);
        #else
            usleep(30000);
        #endif
    }
        
    
    return 0;
}