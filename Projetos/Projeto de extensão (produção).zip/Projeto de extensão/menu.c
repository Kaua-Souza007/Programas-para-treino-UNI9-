#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "menu.h"
#include "cadastro_produtos.h"
#include "listar_produtos.h"
#include "realizar_venda.h"
#include "listar_venda.h"

void menu() {

    int op;

    do {
        printf("\n============ MENU INICIAL ============ \n\n");
        printf("1 - Cadastrar produto\n");
        printf("2 - Listar produtos\n");
        printf("3 - Realizar venda\n");
        printf("4 - Listar vendas\n");
        printf("5 - Sair\n");
        scanf("%d", &op);

        switch(op) {
            case 1:
                system("clear");
                cadastro_produto();
                break;

            case 2:
                system("clear");
                listar_produto();
                break;

            case 3:
                system("clear");
                realizar_venda();
                break;

            case 4:
                system("clear");
                listar_venda();
                break;

            case 5:
                system("clear");
                sleep(1);
                printf("Saindo...\n");
                return 0;
                break;

            default:
                printf("\nDigite um número válido...\n");
                sleep(1); // pausa pra usuário ver
        }

    } while(op != 3);
}