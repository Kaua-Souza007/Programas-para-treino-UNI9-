#include <stdio.h>
#include "cadastro_produtos.h"

void listar_produtos() {

    if (totalProdutos == 0) {
        printf("\nNenhum produto cadastrado\n");
        return;
    }

    printf("\n=== LISTA ===\n");

    for (int i = 0; i < totalProdutos; i++) {
        printf("\nProduto %d\n", i + 1);
        printf("Nome: %s\n", produtos[i].nome);
        printf("Preco: %.2f\n", produtos[i].preco);
        printf("Categoria: %s\n", produtos[i].categoria);
    }
}