#include <stdio.h>
#include "listar_venda.h"

void listar_vendas() {
    printf("\nListando vendas...\n");
}