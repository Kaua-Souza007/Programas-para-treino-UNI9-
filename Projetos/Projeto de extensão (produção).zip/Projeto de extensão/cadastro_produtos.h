#ifndef CADASTRO_PRODUTOS_H
#define CADASTRO_PRODUTOS_H

#define MAX 100

struct Produto {
    char nome[50];
    float preco;
    char categoria[30];
};

// 🔥 declaradas (não criadas aqui)
extern struct Produto produtos[MAX];
extern int totalProdutos;

// funções
void cadastrar_produto(char categoria[]);
void menu_cadastro();

#endif