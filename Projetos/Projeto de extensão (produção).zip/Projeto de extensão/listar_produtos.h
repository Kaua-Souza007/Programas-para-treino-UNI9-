#ifndef LISTAR_PRODUTOS_H
#define LISTAR_PRODUTOS_H

void listar_produtos();

#endif