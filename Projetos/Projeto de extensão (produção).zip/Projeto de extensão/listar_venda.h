#ifndef LISTAR_VENDA_H
#define LISTAR_VENDA_H

void listar_vendas();

#endif