#include <stdio.h>
#include <string.h>
#include "cadastro_produtos.h"

// 🔥 criadas DE VERDADE só aqui
struct Produto produtos[MAX];
int totalProdutos = 0;

void cadastrar_produto(char categoria[]) {

    struct Produto p;

    printf("\nCategoria: %s\n", categoria);

    printf("Nome: ");
    scanf("%s", p.nome);

    printf("Preco: ");
    scanf("%f", &p.preco);

    strcpy(p.categoria, categoria);

    produtos[totalProdutos] = p;
    totalProdutos++;

    printf("\nProduto cadastrado! Total: %d\n", totalProdutos);
}

void menu_cadastro() {

    int op;

    do {
        printf("\n=== Cadastro ===\n");
        printf("1 - Camiseta\n");
        printf("2 - Moletom\n");
        printf("3 - Voltar\n");
        printf("Escolha: ");
        scanf("%d", &op);

        switch(op) {
            case 1:
                cadastrar_produto("Camiseta");
                break;
            case 2:
                cadastrar_produto("Moletom");
                break;
        }

    } while(op != 3);
}