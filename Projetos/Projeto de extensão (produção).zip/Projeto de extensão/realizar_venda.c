#include <stdio.h>
#include "realizar_venda.h"

void realizar_venda() {
    printf("\nRealizando venda...\n");
}

