#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    printf("\n                        ATLAS WEAR\n");
    
    for (i = 0; i < 30; i++) {
      
        printf("\r[")  
        
        
        
    }
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [////            ]");
    printf("                            Carregando");
    fflush(stdout);
    sleep(2);
    system("clear");
    system("clear");
    
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [////////////    ]");
    printf("                            Carregando");
    fflush(stdout);
    sleep(2);
    system("clear");
    
    printf("\n                        ATLAS WEAR\n");
    fflush(stdout);
    printf("                    [///    3         ]");
    printf("                            Carregando");
    fflush(stdout);
    sleep(2);
    

    
    
 
    


    return 0;
}