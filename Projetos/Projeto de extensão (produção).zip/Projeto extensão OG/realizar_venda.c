#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "realizar_venda.h"

void realizar_venda() {
    
    printf("\n teste");
    
    // Esse parte deve registrar a venda e diminuir o produto no banco de dados automaticamente, bl
    // Vou montar a estrutura pra ti
    
    
}