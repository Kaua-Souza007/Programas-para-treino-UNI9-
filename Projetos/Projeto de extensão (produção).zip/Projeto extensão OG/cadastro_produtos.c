#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cadastro_produtos.h"

// 🔥 DEFINIÇÃO REAL (SÓ AQUI)
struct Produto produtos[MAX];
int totalProdutos = 0;

void cadastrar_produto(char categoria[]) {

    if (totalProdutos >= MAX) {
        printf("\nLimite atingido!\n");
        return;
    }

    struct Produto p;

    printf("\nCategoria: %s\n", categoria);

    printf("Nome: ");
    getchar();
    fgets(p.nome, 50, stdin);
    p.nome[strcspn(p.nome, "\n")] = 0;

    printf("Preco: ");
    scanf("%f", &p.preco);

    strcpy(p.categoria, categoria);

    produtos[totalProdutos] = p;
    totalProdutos++;

    printf("\nProduto cadastrado!\n");
    sleep(1);
}

void cadastro_produto() {

    int op;

    do {
        system("clear");

        printf("\n=== Cadastro Produto ===\n");
        printf("1 - Camisetas\n");
        printf("2 - Moletons\n");
        printf("3 - Calcas\n");
        printf("4 - Tenis\n");
        printf("5 - Acessorios\n");
        printf("6 - Voltar\n");

        printf("\nEscolha a categoria desejada: ");
        scanf("%d", &op);

        switch(op) {
            case 1: 
            
                cadastrar_produto("Camisetas"); 
                break;
                
            case 2: 
            
                cadastrar_produto("Moletons"); 
                break;
                
            case 3: 
            
                cadastrar_produto("Calcas"); 
                break;
                
            case 4: 
                cadastrar_produto("Tenis"); 
                break;
                
            case 5: 
                cadastrar_produto("Acessorios"); 
                break;
                
            default: 
                printf("Digite um número valido...");
        }

    } while(op != 6);
}