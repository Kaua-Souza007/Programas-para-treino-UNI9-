numero = 0.1 + 0.1 + 0.1
print(numero == 0.3)
print(numero)