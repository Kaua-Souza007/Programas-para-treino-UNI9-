n1 = int(input("Digite um num: "))
n2 = int(input("Digite um num: "))
n3 = int(input("Digite um num: "))
n4 = int(input("Digite um num: "))
n5 = int(input("Digite um num: "))
n6 = int(input("Digite um num: "))
n7 = int(input("Digite um num: "))
n8 = int(input("Digite um num: "))
n9 = int(input("Digite um num: "))
n10 = int(input("Digite um num: "))

if n1 % 2 == 0:
        print(n1)
else:
    n1 = 0

if n2 % 2 == 0:
        print(n2)
else:
    n2 = 0
    
if n3 % 2 == 0:
        print(n3)
else:
    n3 = 0
    
if n4 % 2 == 0:
        print(n4)
else:
    n4 = 0
    
if n5 % 2 == 0:
        print(n5)
else:
    n5 = 0
    
if n6 % 2 == 0:
        print(n6)
else:
    n6 = 0
    
if n7 % 2 == 0:
        print(n7)
else:
    n7 = 0
    
if n8 % 2 == 0:
        print(n8)
else:
    n8 = 0
    
if n9 % 2 == 0:
        print(n9)
else:
    n9 = 0
    
if n10 % 2 == 0:
        print(n10)
else:
    n10 = 0
    
soma = n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10
print(soma)