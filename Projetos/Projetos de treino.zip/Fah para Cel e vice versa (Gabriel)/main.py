grau_celsius = 0
grau_fahrenheit = 0
opcao = 0

while True:
    opcao = int(input("Digite entre 1 para Celsius e 2 para Fahrenheit: "))
    if opcao == 1:
        grau_fahrenheit = int(input("Digite a temperatura em Fahrenheit: "))
        grau_celsius = (grau_fahrenheit - 32) * 5/9
        print(f"A temperatura é {grau_celsius}°C")
    else:
        if opcao == 2:
            grau_celsius = int(input("Digite a temperatura em Celsius: "))
            grau_fahrenheit = (grau_celsius * 9/5) + 32
            print(f"A temperatura é {grau_fahrenheit}°F")

    opcao = int(input("Digite 3 para sair ou digite qualquer numero para continuar: "))
    if opcao == 3:
        break