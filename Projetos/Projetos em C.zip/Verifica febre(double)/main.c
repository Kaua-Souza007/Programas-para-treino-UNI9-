
#include <stdio.h>

int main()
{
    double temperatura;
    
    printf("Digite a temperatura: ");
    scanf("%lf", &temperatura);
    
    if( temperatura >= 37.3 && temperatura <= 37.8) {
        
        printf("Febríula!");
    }
    
    else if (temperatura > 37.8 && temperatura < 39) {
        
        printf("Febre!");
    }
    
    else if (temperatura >= 39) {
        
        printf("Febre alta!!!");
    }
    
    else {
        
        printf("Não é febre!");
    }

    return 0;
}