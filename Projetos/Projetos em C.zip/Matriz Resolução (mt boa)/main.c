#include <stdio.h>
#define VENDEDOR 2
#define DIA 3


int main()
{
    
    double vendas[VENDEDOR][DIA]; // 4 vendedores, 5 dias.]
    double Totaldia[DIA] = {0,0,0}, totalvendedor[VENDEDOR] = {0,0};
    int i, j;
    double total = 0;
    
//     0  1  2  3  4 (j) (dia)
//    {1, 3, 5, 7, 5}, 0 (i) (vendedores)
//    {2, 4, 6, 8, 6}, 1 (i)
//    {1, 9, 2, 6, 7}, 2 (i)
//    {1, 9, 2, 6, 8}  3 (i)
    
    printf("\n======= Sistema de Vendas =======\n");
    
    for (i = 0; i < VENDEDOR; i++) {
        
        printf("\n\nVendedor %d: \n", i+1);
        
        for (j = 0; j < DIA; j++) {
        
        printf("\nDigite o valor da venda %d: ", j+1);
        scanf("%lf", &vendas[i][j]);
        
            
        }    
        
        
    }
    
    printf("\n\n-------- Vendas -------- ");
    for (i = 0; i < VENDEDOR; i++) {
        
        printf("\n\nVendedor %d: \n", i+1);
        
        for (j = 0; j < DIA; j++) {
        
        printf("\nDia %d: R$ %2.lf", j+1, vendas[i][j]);
        
            
        }    
    }
    
    
    printf("\n\n====== Relatorio de vendas ======\n");
    
    //for (i = 0; i < VENDEDOR; i++) {
        
      //  for (j = 0; j < DIA; j++) {
            
        //    if (i == 0) {
            
          //  total = total + vendas[0][j];
            
            //}
        //}
        
        for (i = 0; i < VENDEDOR; i++) {
                
                for (j = 0; j < DIA; j++) {
                
                if(i ==0)
                    totalvendedor[i] = totalvendedor[i] + vendas[i][j];
                
                    
                }
            
            }
        
        //printf("\nTotal do Vendedor %d: %2.lf", i+1, total);
        
        //parcial falta fazer funcionar o total do 2.
        printf("\nTotal do Vendedor 1: %2.lf", totalvendedor[0]);
        printf("\nTotal do Vendedor 2: %2.lf", totalvendedor[1]);
    
    
    

    return 0;
}
