#include <stdio.h>

int main()
{
  int contador, valor_inicial, valor_final;
  
  printf("digite o valor_inicial: ");
  scanf("%d", &valor_inicial); 
  
  printf("digite o valor_final: ");
  scanf("%d", &valor_final);
  
    for(contador = valor_inicial; contador <= valor_final; contador++) {
        
    printf("--> %d\n", contador);
    
    }
    
    for (contador = valor_inicial; contador >= valor_final; contador--) {
        
    printf("--> %d\n", contador);    
        
    }
  

    return 0;
}

