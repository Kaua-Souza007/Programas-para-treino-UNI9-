#include <stdio.h>

int main()
{
    double peso, altura, imc;
    printf("digite o peso(kg): ");
    scanf("%lf", &peso);
    printf("digite a altura (metros): ");
    scanf("%lf", &altura);
    imc= peso / (altura * altura);
    
    if(imc <= 18.5) {
    
    printf("IMC: %2lf\tAbaixo do peso\n", imc);
        
    }
    else if(imc > 18.5 && imc <25.0) {
        
    printf("IMC: %2.lf\tnormal\n", imc);
        
    }
    else if(imc >= 25.0 && imc <30.0) {
     
     printf("IMC: %2.lf\tsobre peso\n", imc);
        
    }
    else if(imc >= 30.0 && imc <35.0) {
    
        printf("IMC: %2.lf\tobesidade grau I\n", imc);
        
        
    }
    else if(imc >= 35.0 && imc <40.0) {
        
       printf("IMC: %2.lf\tObesidade grau II\n", imc); 
       
       
    }
    else {
        
    printf("IMC: %2.lf\tObesidade grau III\n", imc); 
    }
    
    
    
    
   
    
    
    return 0;
}
