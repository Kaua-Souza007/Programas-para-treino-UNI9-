#include <stdio.h>

int main()
{
    // Corrigindo o erro classico do ponto flutuante: 
    
    double numero;
    
    numero = 1.3;
    
    printf("numero = %lf \n", numero);

    if (numero == 1.3) {
        
        printf("é igual");
        
    }
    
    else {
        
        printf("é diferente");
        
    }
    

    return 0;
}
