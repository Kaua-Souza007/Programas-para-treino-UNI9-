
#include <stdio.h>

int main()
{
    double salario, Imposto;
    
    printf("---------------Calculo do Imposto de renda---------------\n");
    
    printf("\nDigite seu sálario mensal: R$ ");
    scanf("%lf", &salario);
    
    if (salario <= 2428.80) {
        
        printf("Isento");
        
    }
    
    else if (salario > 2428.81 && salario <= 2826.65) {
        
        printf("\nAliquota de 7.5%%");
        
        Imposto = (salario * 7.5 / 100) - 182.86;
        
        printf("\nO valor a pagar é: R$ %2.lf", Imposto);
        
        
        
    }
    
    else if (salario > 2826.65 && salario <= 3751.05) {
        
        printf("\nAliquota de 15.0%%");
        
        Imposto = (salario * 15  / 100) - 394.16;
        
        printf("\nO valor a pagar é: R$ %2.lf", Imposto);
        
    }
    
    else if (salario > 3751.05 && salario <= 4665.68) {
        
        printf("\nAliquota de 22.5%%");
        
        Imposto = (salario * 22.5 ) / 100) - 675,49;
        
        printf("\nO valor a pagar é: R$ %2.lf", Imposto);
        
    }
    
    else {
        
        printf("\nAliquota de 27.5%%");
        
        Imposto = (salario * 27.5  / 100) - 908.73;
        
        printf("\nO valor a pagar é: R$ %2.lf", Imposto);
        
    }

    return 0;
}
