#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    
    int Corintians = 0, SãoPaulo = 0, Palmeras = 0, Santos = 0, Portuguesa = 0;
    int contador, TimeEsc = 0, contInvalido = 0;
    
    for(contador = 1; contador <= 5; contador++) {
    
    printf("\n-----------Escolha time-----------\n");
    printf("\n1- Corintians\n2- Palmeras\n3- São Paulo\n4- Santos\n5- Portuguesa");
    
    printf("\nDigite o seu time do coração: ");
    scanf("%i", &TimeEsc);
    
    switch(TimeEsc) {
        
        case 1: 
        
            Corintians++;
            break;

        case 2:
        
            Palmeras++;
            break;
        
        case 3:
        
            SãoPaulo++;
            break;
            
        case 4:
        
            Santos++;
            break;
    
        case 5:
        
            Portuguesa++;
            break;
            
        default:
        
            system("clear");
            printf("\nDigite um numero valido:\n ");
            continue;

    }
    
    system("clear");
    printf("\n------Placar------");
    printf("\nCorintians: %d", Corintians);
    printf("\nPalmeras: %d", Palmeras);
    printf("\nSão Paulo: %d", SãoPaulo);
    printf("\nSantos: %d", Santos);
    printf("\nPortuguesa: %d\n\n", Portuguesa);
    
    }

    return 0;
}
