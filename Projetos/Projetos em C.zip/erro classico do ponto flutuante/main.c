#include <stdio.h>

int main()
{
    // erro classico do ponto flutuante: 
    
    float numero;
    
    numero = 1.3;
    
    printf("numero = %f \n", numero);

    if (numero == 1.3) {
        
        printf("é igual");
        
    }
    
    else {
        
        printf("é diferente");
        
    }
    

    return 0;
}
