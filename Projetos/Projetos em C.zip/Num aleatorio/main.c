#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    
    int contador=1;
    srand(time(NULL));
do{
    
    
    printf("\n%d", rand() % 60+1);
    contador++;
}while(contador <= 6);

    return 0;
}
