#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main()
{
    
    int escolhaUsu = 0, curtidas = 0;
    
    do {
    
    printf("\n------------Rede Social------------\n");
    
    printf("1- Curtir uma Postagem\n2- Ver quantidade de curtidas\n3- Sair");
    
    printf("\n\nDigite sua opção: ");
    scanf("%i", &escolhaUsu);
    
    
    switch(escolhaUsu) {
        
        case 1: 
            
            system("clear");
            printf("\nCurtida enviada!!!\n");
            curtidas++;
            break;
        
        case 2: 
        
            system("clear");
            printf("\nSeu numero atual de curtidas é: %d\n", curtidas);
            break;
            
        case 0: 
            
            system("clear");
            printf("\nPrograma encerrado....");
            return 0;
            break;
        
        default: 
        
            printf("Digite uma opção valida: ");
            continue;
    }

    }while (escolhaUsu > 0);
    
    return 0;
}