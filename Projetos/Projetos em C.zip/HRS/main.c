#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    
    int seg, min, dia, horas;

    seg = 0;
    min = 0;
    horas = 0;
    dia = 0;
    
    while(1) {
        
        system("clear");
        seg++;
        
        if (seg == 60) {
            
            min++;
            seg = 0;
            
        }
        
        if (min == 60) {
            
            horas++;
            min = 0;
            
        if (dia == 24){
            
            horas ++;
            dia = 0;
        }    
            
        }
        printf("%2d:%2d:%2d \n\a", horas, min, seg, dia);
        usleep(0.5);
        
    }




    return 0;
}
