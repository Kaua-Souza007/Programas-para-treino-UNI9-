#include <stdio.h>

int main()
{
    int contador;
    double altura, soma=0, media;
    
    for(contador = 1; contador <= 5; contador++){
        printf("\nDigite a altura da %iª pessoa: ", contador);
        scanf("%lf", &altura);
        soma = soma + altura;
        media = soma / contador;
        printf("a media: %.2lf", media);
}
    return 0;
}
