#include <stdio.h>
#define X 7

int main()
{
    int idade[X];
    int contador, media = 0;
    
    for (contador = 0; contador < X; contador++) {
        
        printf("\ndigite a idade: ");
        scanf("%d", &idade[contador]);
        
        media = media + idade[contador];
        
    }
    
    media = media / 7;
    
    printf("A media é: %d", media);


    return 0;
}
