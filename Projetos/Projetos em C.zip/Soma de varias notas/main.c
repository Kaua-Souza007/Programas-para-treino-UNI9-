#include <stdio.h>

int main()
{
    double i = 1, n = 0, notatp, notaf;
    
    
    do {
        
        scanf("%lf", &notatp);
        
        if (notatp >= 0) {
        
        notaf = notaf + notatp;
        
        notatp = 0;
        
        i++;
        
        }
        
        else {
        
        n = i + 1;
        
        }
        
    } while (i > n);
    
    printf("%2.lf", notaf);

    return 0;
}
