#include <stdio.h>

// x = -b +/- (D b^2 - 4 . a . c) / 2 .a;

int main()
{
    
    int a, b, c, delta,  bashara1, bashara2;
    
    printf("\nDigite a: ");
    scanf("%d", &a);
    
    printf("\nDigite b: ");
    scanf("%d", &b);
    
    printf("\nDigite c: ");
    scanf("%d", &c);
    
    delta = b^2 - 4 * a * c;
    
    bashara1 = ((b * -1) + delta) / (2 * a);
    
    bashara2 = ((b * -1) - delta) / (2 * a);
    
    printf("\n B1 = %d", bashara1); 
    
    printf("\n B2 = %d", bashara2);
    
    
    return 0;
}