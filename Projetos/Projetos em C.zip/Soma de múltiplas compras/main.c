#include <stdio.h>

int main()
{
    double preco, soma = 0;
    
    do{
    
    printf("Digite o preço");
    scanf("%lf", &preco);
    soma = soma+preco;
    printf("soma: R$%.2lf \n\n", soma);
    
    } while (preco != 0 );
    
    
    return 0;
}
