#include <stdio.h>

int main()
{
    int contador = 1, quantidade = 0;
    double valor = 0, totalValor = 0, media = 0;
    
    printf("Digite a quantidade de operações realizadas:");
    scanf("%i", &quantidade);
    
    do {
       
       printf("\nDigite o valor da %d operação: ", contador);
       scanf("%lf", &valor);
       contador++;
       
       totalValor = totalValor + valor;
       
    }while (contador <= quantidade);
    
    media =  totalValor  / quantidade;
    
    printf("\nO total das operações é: %2.lf", totalValor);
    printf("\nEnquanto a média dos gastos é: %2.lf", media);
    
    
    return 0; 
}
