#include <stdio.h>

int main()
{
    int i, n1, n2, op, c;
    
    for (i = 0; i <= 10; i++) {
    
    printf("\n1 - mais\n2 - menos\n3 - divisao\n4 - vezes\n");
    printf("\nDigite a op: ");
    scanf("%i", &c);
    
    printf("\nDigite o n1: ");
    if (scanf("%i", &c) != 1) {
    printf("\nNumero invalido!\n");
    while (getchar() != '\n');
    continue;
}
    
    printf("\nDigite o n2: ");
    if (scanf("%d", &n2) != 1) {
    printf("\nNumero invalido!\n");
    while (getchar() != '\n');
    continue;
}
    
    
    
    
    if (c == 1) {
        
        op = n1 + n2;
        printf("\n seu resultado é %d ", op);
    }
    
    else if (c == 2) {
        
        op = n1 - n2;
        printf("\n seu resultado é %d ", op);
        
    }
    
    else if (c == 3) {
        
        op = n1 / n2;
        printf("\n seu resultado é %d ", op);
        
    }
    
    else if (c == 4) {
        
        op = n1 * n2;
        printf("\n seu resultado é %d ", op);
        
    }
    
    else {
        
        printf("\nDigite um num valido\n");
        continue;
        
    }
    
    
    }
    
    
    
    

    return 0;
}
