
#include <stdio.h>

int main()
{
    // %s.\n = tipo de dado, condição
    // (x) ? = sinalização de condição
    // (x) : (x) Condição true : false
    
    int numero, bonus;
    
    printf("Digite um número inteiro: ");
    scanf("%d", &numero);
    
    printf("O numero é %s.\n", (numero % 2 == 0) ? "par" : "impar");
    printf("O número é %s.\n", (numero > 0) ? "positivo" : (numero < 0 ? "negativo" : "zero"));

    bonus = (numero >=10) ? 1000:100;
    
    printf("Bônus calcaulado: %d\n", bonus);
    
    return 0;
}
