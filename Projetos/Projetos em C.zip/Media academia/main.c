#include <stdio.h>

int main()
{
    int contador;
    double aluno = 0, media = 0;
    
    for(contador = 1; contador <= 7; contador++) {
        
        printf("Digite a idade do %d aluno da academia: ", contador);
        scanf("%lf", &aluno);
        media = media + aluno;
        
    }
    
    media = media / 7;
    
    printf("\n\nA média das idades é: %2.lf", media);

    return 0;
}
