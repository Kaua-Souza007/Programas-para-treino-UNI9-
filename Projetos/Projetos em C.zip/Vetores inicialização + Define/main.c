#include <stdio.h>
#define TAM 10

int main()
{
    
    //int numeros[5] = {2, 50, 30, 1, 4};
    
    int numeros[TAM] = {0, 0, 0, 0, 0};
    int contador;
    
    for (contador = 0; contador < TAM; contador++) {
        
        printf("\nDigite: ");
        scanf("%d", &numeros[contador]);  
        
    }
    
    printf("\n");
    
    for(contador = 0; contador < TAM; contador++) {
    
    printf("\nnumeros[%d] = %d",contador, numeros[contador]);
        
    }
    


    return 0;
}