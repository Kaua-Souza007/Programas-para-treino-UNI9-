
#include <stdio.h>

int main()
{
    int num;
    
    printf("Digite um numero válido:\n ----------------- \n 1 - Domingo\n 2 - Segunda\n 3 - terça\n 4 - quarta\n 5 - quinta\n 6 - sexta\n 7 - sabado\n  ----------------- \n");

    scanf("%i",&num);
    
    switch(num) {
    
        case 1:
        
            printf("domingo");
            break;
            
        case 2:
            
            printf("segunda");
            break;
            
        case 3:
        
            printf("terça");
            break;
            
        case 4:
            
            printf("quarta");
            break;
            
        case 5:
        
            printf("quinta");
            break;
            
        case 6:
        
            printf("sexta");
            break;
            
        case 7:
        
            printf("sabado");
            break;
            
        default:
        
            printf("Digite um numero valido!!!");
            
    }
    return 0;
}