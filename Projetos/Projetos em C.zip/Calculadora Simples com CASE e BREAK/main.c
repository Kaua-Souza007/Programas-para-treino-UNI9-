#include <stdio.h>

int main()
{
    
    double num1, num2, result;
    
    char operacao;
    
    printf("\n-------------Calculadora Simples-------------");
    
    printf("\n\n + Soma\n - subitração\n * Multiplicação\n / Divisão\n");
    
    printf("\n-----------------------------------------------\n");
    
    printf("Digite a operação desejada: ");
    scanf("%c", &operacao);
    
    printf("Digite o primeiro numero: ");
    scanf("%lf", &num1);
    
    printf("Digite o segundo numero: ");
    scanf("%lf", &num2);

        switch(operacao) {
         
            case '+':
                result = num1 + num2;
                 break;

            case '-':
                result = num1 - num2;
                 break;

            case '*':
            case 'x':
            case 'X':
            case '.':
                result = num1 * num2;
                 break;

            case '/':
            case ':':
                result = num1 / num2;
                 break;
                 
        default:
            
            printf("\nDigite apenas os caracteres: + - * /\n");
        }
        
    printf("Resultado: %2.lf", result);    
        

    return 0;
}
