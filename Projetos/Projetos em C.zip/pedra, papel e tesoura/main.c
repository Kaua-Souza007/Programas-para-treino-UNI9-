#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
int main()
{

    int bot, jogador = 0, plUsu = 0, plBot = 0, empates = 0;
    
    

    do {
        
        system("clear");
        printf("\n------------PEDRA PAPEL OU TESOURA------------\n");
        printf("\n------------------------------------------------\n");

        printf("1 - Pedra\n2 - Papel\n3 - Tesoura\n");

        printf("\nDigite a sua opção: ");
        scanf("%i", &jogador);

            if ((jogador < 1) || (jogador > 3)){
            
            
                printf("selecione uma opcao valida");
                continue; // continua o codigo, volta antes desse comando
                sleep(2);
            
        }


    
        srand(time(NULL));
        bot = (rand()  % 3) + 1;
        
            if(bot == 1){
            
                printf("Bot: %i - Pedra\n", bot);
        
            }
        
            else if (bot == 2){
            
                printf("Bot: %i - Papel\n", bot);
            
            }
        
            else {
            
                printf("Bot: %i - Tesoura\n", bot);
            
            }
            if (bot == jogador) {
            
                printf("Empate\n\n");
                empates++;
            
            }
        
            else if ((bot == 1 && jogador == 2) || (bot == 2 && jogador == 3) || (bot == 3 && jogador == 1)) {
            
            
                printf("Derota\n\n");
                plBot++;
            
            }
        
            else {
            
                printf("Vitoria\n\n");
                plUsu++;
            
            }
            
        printf("----------------------------------------------\n");
        sleep(2);
        
        printf("\n-------------------- Placar --------------------");
            
        printf("\nPlacar do Bot: %i", plBot);
        printf("\nPlacar do Player: %i", plUsu);
        printf("\nEmpates: %i", empates);
        
        printf("\n----------------------------------------------");
        printf("\n----------------------------------------------");
        sleep(8);

    }while(1);

        

    return 0;
}