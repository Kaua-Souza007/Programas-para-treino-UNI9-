#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    
    int contador=1, sorteio, palpite;
    srand(time(NULL));
    sorteio = rand()  % 99 + 1;
    
    do {
    printf("\nDigite seu palpite: ");
    scanf("%d", &palpite);
    
    if (palpite == sorteio){
        
        printf("\nACEROU!!!!");
    }
    
    else {
        
        printf("\nErrou, não foi dessa vez ;-;");
        
            if (palpite < sorteio) {
        
                printf("\nSeu numero é menor que o numero sorteado\n");
        
            }
    
            else {
        
                printf("\nSeu numero é maior que o numero  sorteado\n");
        
            } 
    
    }
    
    }while(palpite != sorteio);
    
    printf("\nSorteio: %d", sorteio);
    

    return 0;
}
