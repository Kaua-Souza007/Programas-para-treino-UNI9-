#include <stdio.h>

int main()
{
    
    // "SWICH" =  Verificação o status dos casos, verdadeiro ou falso.
    // "CASE" =  Celulas de codificação, são usadas para admin istrar uma quantidade alta de variaveis e possibilidades, usa pouca memoria.
    // "Default" = Situação fora do codigo iniial, (else).
    // "Break" = Interrompe o Codigo. Semelhante ao }
    
    int mes;
    

    printf("Digite o numero do mês: ");
    scanf("%d", &mes);
    
    switch(mes) {
        case 1:
            printf("Janeiro");
             break;
             
        case 2:
            printf("Fevereiro");
             break;
             
        case 3:
            printf("Março");
             break;
             
        case 4:
            printf("Abril");
             break;
             
        case 5:
            printf("Maio");
             break;
             
        case 6:
            printf("Junho");
             break;
             
        case 7:
            printf("Julho");
             break;
             
        case 8:
            printf("Agosto");
             break;
             
        case 9:
            printf("Setembro");
             break;
             
        case 10:
            printf("outubro");
             break;
             
        case 11:
            printf("Novembro");
             break;
             
        case 12:
            printf("Dezembro");
             break;
             
        default:
        
            printf("Codigo invalido");
    }

    return 0;
}
