#include <stdio.h>

int main()
{
    int contador;
    for(contador = 1; contador <= 20000000; contador++){
        printf("%d -", contador);
    
    }

    return 0;
}