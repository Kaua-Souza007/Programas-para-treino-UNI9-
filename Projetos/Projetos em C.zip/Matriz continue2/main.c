#include <stdio.h>

int main()
{
    int matriz[4][5]; 
    
//     0  1  2  3  4 (j)
//    {1, 3, 5, 7, 5}, 0 (i)
//    {2, 4, 6, 8, 6}, 1 (i)
//    {1, 9, 2, 6, 7}, 2 (i)
//    {1, 9, 2, 6, 8}  3 (i)
    
    int Dia = 0, DiaIlus = 0, vendedor = 0, i, j, posi = 0, soma = 0;
    
    for(i = 0; i < 4; i++) {
        
        DiaIlus++;
        
        for(j = 0; j < 5; j++) {
        
        printf("\nDigite o valor do %d vendedor na posição %d: ", DiaIlus, posi);
        posi++;
        scanf("%d", &matriz[i][j]);
        
        soma = soma + matriz[i][j];
        
        if (posi > 4) {
            
            posi = 0;
        }
        }
        
    }


    return 0;
}
