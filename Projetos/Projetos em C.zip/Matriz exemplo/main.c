#include <stdio.h>

int main()
{
    int matriz[3][4] = {
        
        
//   0  1  2  3 (j)
    {1, 3, 5, 7}, // 0 (i)
    {2, 4, 6, 8}, // 1 (i)
    {1, 9, 2, 6}  // 2 (i)
        
    };
    
    int i, j;
    
    printf("\nDigite o valor da coluna (j): ");
    scanf("%d", &i);
    
    printf("\nDigite o valor da linha: (i): ");
    scanf("%d", &j);
    
    if (i > 3 || j > 3) {
        
        printf("\nErro...");
        
    }
    
    else {
    
    for (i = i; i < 3; i++) {
        
        for (j = j; j < 4; j++) {
            
        printf("%d ", matriz[i][j]);
            
        }
        
        printf("\n");
    }
    
    }
    return 0;
}