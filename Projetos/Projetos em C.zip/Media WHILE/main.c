
#include <stdio.h>

int main()
{
    
    int contador;
    double med1, med2, med3, media;
    
    contador = 1;
    
    while (contador == 1) {
        
    printf("\n----------Boletim %d aluno----------\n", contador);
    
    printf("\nDigite a primeira nota: ");
    scanf("%lf", &med1);
    
    while (med1 < 0 || (med1 > 10)) {
        
        printf("\nDigite a primeira nota novamente\n(Entre 0 e 10): ");
        scanf("%lf", &med1);
    }
    
    printf("\nDigite a segunda nota: ");
    scanf("%lf", &med2);
    
    while (med2 < 0 || (med2 > 10)) {
        
        printf("\nDigite a segunda nota novamente\n(Entre 0 e 10): ");
        scanf("%lf", &med2);
    }
    
    printf("\nDigite a terceira nota: ");
    scanf("%lf", &med3);
    
    while (med3 < 0 || (med3 > 10)) {
        
        printf("\nDigite a terceira nota novamente\n(Entre 0 e 10): ");
        scanf("%lf", &med3);
    }
        
    media = (med1 + med2 + med3) / 3;
    printf("\nA média geral do aluno é: %.2lf \n", media);
    contador++;
    }

    return 0;
}
