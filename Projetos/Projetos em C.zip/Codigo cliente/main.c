
#include <stdio.h>

int main()
{
    
    double valorCompra = 0, totalComDesconto = 0;
    int TipoCliente;
    
    printf("\n$$$$$$$ Compra $$$$$$$\n");
    
    printf("\n(1) - Cliente\n");
    printf("(2) - Funcionario\n");
    printf("(3) - Vip\n");
    
    printf("\nDigite o valor da compra: R$ ");
    scanf("%lf", &valorCompra);
    
    printf("Digite o codigo do cliente: ");
    scanf("%d", &TipoCliente); 
    
    switch (TipoCliente) {
        
        case 1:
        
            printf("Valor da compra: %2.lf.", valorCompra);
            break;
        
        case 2: 
            
            totalComDesconto = valorCompra - valorCompra * 10/100;
            printf("O valor da compra com desconto: R$ %2.lf", totalComDesconto);
            break;
            
        case 3: 
        
            totalComDesconto = valorCompra - valorCompra * 5/100;
            printf("Valor da compra com desconto: R$ %2.lf", totalComDesconto);
            break;
        
        default:
        
            printf("\nCódigo de cliente não reconhecido!!!");
        
    }
    
    return 0;
}