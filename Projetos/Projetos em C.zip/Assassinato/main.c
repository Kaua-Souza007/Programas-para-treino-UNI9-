#include <stdio.h>

int main()
{
    char resposta;
    int contador = 0;

    printf("\nVocê ligou para a vítima?: ");
    scanf(" %c", &resposta);
    if (resposta == 's' || resposta == 'S') {
        contador++;
    }

    printf("\nVocê mora perto da vítima?: ");
    scanf(" %c", &resposta);
    if (resposta == 's' || resposta == 'S') {
        contador++;
    }

    printf("\nVocê devia para a vítima?: ");
    scanf(" %c", &resposta);
    if (resposta == 's' || resposta == 'S') {
        contador++;
    }

    printf("\nVocê estava no mesmo local da vítima?: ");
    scanf(" %c", &resposta);
    if (resposta == 's' || resposta == 'S') {
        contador++;
    }

    printf("\nVocê trabalhou com a vítima?: ");
    scanf(" %c", &resposta);
    if (resposta == 's' || resposta == 'S') {
        contador++;
    }

    // Classificação (AGORA NO FINAL)
    if (contador < 2) {
        printf("\nInocente");
    }
    else if (contador == 2) {
        printf("\nSuspeito");
    }
    else if (contador <= 4) {
        printf("\nCúmplice");
    }
    else {
        printf("\nAssassino");
    }

    printf("\nTotal de respostas positivas: %d", contador);

    return 0;
}