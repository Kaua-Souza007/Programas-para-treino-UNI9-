#include <stdio.h>

int main()
{
    
    double Etanol, Gasolina, calculoGas;
    char continua; 
    
    do { 
        
        printf("\n---------Calculo Combustivel---------\n");
        
        printf("\nDigite o valor do Etanol por Litro: R$ ");
        scanf("%lf", &Etanol);
    
        printf("Digite o valor da Gasolina por Litro: R$");
        scanf("%lf", &Gasolina);
        
        printf("\n---------------------------------------------\n");
        
        calculoGas = Gasolina * 0.7;
        
        printf("Gasolina calculada: %2.lf", calculoGas);
        
        if (calculoGas <= Etanol) {
            
            printf("\nA gasolina vale mais a pena!!!");
            
        }
        
        else {
            
            printf("\nO Etanol vale mais a pena!!!");
            
        }
        
        printf("\n---------------------------------------------\n");
        
        printf("\nDeseja continuar (s/n)? ");
        scanf(" %c", &continua);
        
    printf("\n---------------------------------------------\n");
    
    } while (continua == 's'|| continua == 'S');

    return 0;
}
