#include <stdio.h>

int main()
{
    
    char ua;
    
    ua = 'U';
    
    printf("Texto colorido\n");
    
    printf("Texto: \033[1;33;41mUNINOVE\033[m\n");
    
    printf("Texto: \033[1;31;47mUNI\033[m" "\033[1;96;47mNOVE\033[m");
    
    printf("Texto: \033[1;31;47m%c\033[m", ua);

    return 0;
}
