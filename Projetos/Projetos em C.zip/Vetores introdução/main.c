#include <stdio.h>

int main()
{
    double vetor[5];
    vetor[2] = 4.5;
    vetor[3] = 5.0;
    
    printf("\nvetor[0] = %.2lf\n", vetor[0]);
    printf("vetor[1] = %.2lf\n", vetor[1]);
    printf("vetor[2] = %.2lf\n", vetor[2]);
    printf("vetor[3] = %.2lf\n", vetor[3]);
    printf("vetor[4] = %.2lf\n", vetor[4]);

    return 0;
}