#include <stdio.h>

int main()
{
    int entrada[20];
    int par[20], impar[20];
    int i, contPar = 0, ContImpar = 0, contador = 1;
    
    
    for (i = 0; i < 20; i++){
    
        printf("\n Digite o %d numero inteiro: ", i + 1);
        scanf("%d", &entrada[i]);
    
    
    //classificação impar ou par: 
    
    if (entrada[i] % 2 == 0) {
        
        par[contPar] =  entrada[i];
        contPar++;
        
    }
    
    else {
        
        impar[ContImpar] =  entrada[i];
        ContImpar++;
        
    }
    
    }
    
    // Exibição do vetor entrada:
    
    printf("\nVetor ENTRADA: \n");
    
    for (i = 0; i < 20; i++) {
        
        
        printf("\n%d - %d",contador, entrada[i]);
        contador++;
        
    }
    
    contador = 0;
    
    // exibindo vetor par: 
    printf("\n\nPares: \n");
        
    for (i = 0; i < contPar; i++) {
        
        printf("\n%d - %d",contador ,par[i]);
        contador++;
        
        
    }
    
    printf("\n\nImpares: \n");
    contador = 0;
    
    for (i = 0; i < ContImpar; i++) {
        
        
        printf("\n%d - %d",contador ,impar[i]);
        contador++;
        
        
    } 
    return 0;
}
