#include <stdio.h>

int main()
{
    int contador;
    
    for (contador = 1; contador <= 100; contador++ ) {
        
        if(contador % 2 == 1) {
            printf("%d - impar \n",contador);
            
        }
        else {
            
            printf("%d - par\n", contador);
            
        }
        
    }

    return 0;
}
