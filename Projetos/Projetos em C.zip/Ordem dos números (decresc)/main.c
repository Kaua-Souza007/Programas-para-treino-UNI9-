#include <stdio.h>

int main()
{
    int numero1, numero2 , numero3;
    
    printf("digite o primeiro numero: ");
    scanf("%d", &numero1);
    printf("digite o segundo numero: ");
    scanf("%d", &numero2);
    printf("digite o terceiro numero: ");
    scanf("%d", &numero3);
    
    if ((numero1 >= numero2) && (numero2 >= numero3)) { // 1 2 3
        
        printf("%d, %d e %d", numero1, numero2, numero3);
        
    }
    
    else if ((numero1 >= numero3) && (numero3 >= numero2)) { // 1 3 2
        
       printf("%d, %d e %d", numero1, numero3, numero2);
        
    }
    
    else if ((numero2 >= numero1) && (numero1 >= numero3)) { // 2 1 3
        
        printf("%d, %d e %d", numero2, numero1, numero3);
        
    }
    
    else if ((numero2 >= numero3) && (numero3 >= numero1)) { // 2 3 1
        
        printf("%d, %d e %d", numero2, numero3, numero1);
        
    }
    
    else if ((numero3 >= numero1) && (numero1 >= numero2)) { // 3 1 2
        
        printf("%d, %d e %d", numero3, numero1, numero2);
        
    }

    else if ((numero3 >= numero2) && (numero2 >= numero1)) { // 3 2 1
        
        printf("%d, %d e %d", numero3, numero2, numero1);
        
    }
    
    else { // falha
        
        printf("Não consigo ler");
        
    }
    
    return 0;
}
