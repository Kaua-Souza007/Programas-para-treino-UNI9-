#include <stdio.h>

int main()
{
    int op, i;
    float num1, num2, result;
    
    for (i = 0; i <=5; i++) {
    
    printf("---------Calculadora Simples---------");
    
    printf("\n1 - Soman\n 2 - Subtração\n 3 - Multiplicação\n 4 - Divisão");
    
    printf("\nDeseja usar qual tipo de operação?: ");
    scanf("%d", &op);
    
    printf("\nDigite o primeiro numero: ");
    scanf("%f", &num1);
    
    printf("\nDigite o segundo numero: ");
    scanf("%f", &num2);
    
    if (op == 1) {
        
        result = num1 + num2;
        printf("O resultado da operação é: %2.f", result);
        
    }
    
    else if (op == 2) {
        
        result = num1 - num2;
        printf("O resultado da operação é: %2.f", result);
        
    }
    
    else if (op == 3) {
        
        result = num1 * num2;
        printf("O resultado da operação é: %2.f", result);
        
    }
    
    else if (op == 4) {
        
        result = num1 / num2;
        printf("O resultado da operação é: %2.f", result);
        
    }
    
    else {
        
        printf("\nDIGITE UM NUMERO VALIDO!!!!!");
    }
    
    return 0;
}