#include <stdio.h>

int main()
{
    int matriz[3][4] = {
        
        
//   0  1  2  3 (j)
    {1, 3, 5, 7}, // 0 (i)
    {2, 4, 6, 8}, // 1 (i)
    {1, 9, 2, 6}  // 2 (i)
        
    };
    
    int i, j;
    
    printf("\n Matriz \n");
    for (i = 0; i < 3; i++) {
        
        for (j = 0; j < 4; j++) {
            
        printf("matriz[%d][%d] ", i,j);
        scanf("%d", &i);
            
        }
        
        printf("\n");
    
    }
    
    
    for (i = 0; i < 3; i++) {
        
        for (j = 0; j < 4; j++) {
    
        printf("matriz[%d][%d] ", i,j);
        scanf("%d", &j);
        
    }
    }
    return 0;
}
