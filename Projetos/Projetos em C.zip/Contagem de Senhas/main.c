
#include <stdio.h>

int main()
{
    int senha, senha_digitada, tentativa, ilustra;
    
    ilustra = 3;
    tentativa = 0;
    senha = 406070; //senha cadastrada
    senha_digitada = 0; //usuario vai digitar
    
    while(senha != senha_digitada){
        printf("\n---------login no sistema---------\n");
        printf("\ndigite a senha: ");
        scanf("%d", &senha_digitada);
    if(senha == senha_digitada){
        printf("\nlogin efetuado com sucesso!\n\n");
    }
    
    else{
        printf("\nsenha incorreta!\n\n");
        tentativa++;
        ilustra--;
        printf("\nVocê tem mais %d tentativas\n", ilustra);
        printf("\n------------------------------------------\n\n\n");
        if (tentativa >= 3) {
            printf("================================================\n");
            printf("\nSistema bloqueado por excesso de tentativas!!!\n\n");
            printf("================================================\n");
            break;
            
        }
        ;
    }

}
    return 0;
}
