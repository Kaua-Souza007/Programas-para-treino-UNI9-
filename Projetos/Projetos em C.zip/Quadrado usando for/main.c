#include <stdio.h>
#include <unistd.h>

int main()
{
    int linha, colunas;
    int contlinhas, contcolunas;
    
    printf("digite a quantidade de linha: ");
    scanf("%d", &linha);
    
     printf("digite a quantidade de colunas: ");
    scanf("%d", &colunas);
    
    
    for(contlinhas = 1; contlinhas <= linha; contlinhas++) {
        
        printf("\n");
        
    
        for(contcolunas = 1; contcolunas <= colunas; contcolunas++) {
            
            if(contlinhas == 1 || contlinhas == linha ||
            contcolunas == 1 || contcolunas == colunas) {
                printf("# ");}
            else{
                printf("  ");}
            
            usleep(10000);
    
        }
    
    }
    
    

    return 0;
}
