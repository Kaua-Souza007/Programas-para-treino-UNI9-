#include <stdio.h>

int main()
{
    int contador, tabuada = 1;
    
    for (tabuada = 1; tabuada < 10; tabuada++){
        
        printf("\ntabuada do %d: \n", tabuada);
        
            for (contador = 0; contador <= 10; contador++ ) {
        
                printf("%d x %d = %d\n",tabuada, contador, contador * tabuada );
    
            }
    }

    return 0;
}
