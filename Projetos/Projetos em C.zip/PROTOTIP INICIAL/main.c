// 🔹 Funções (exemplo)
void cadastro_produto() {
    printf("Cadastro de produto...\n");
}

void listar_produto() {
    printf("Lista de produtos...\n");
}

void cadastro_venda() {
    printf("Cadastro de venda...\n");
}

void listar_venda() {
    printf("Lista de vendas...\n");
}