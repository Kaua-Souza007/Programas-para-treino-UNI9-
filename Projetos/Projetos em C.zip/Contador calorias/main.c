#include <stdio.h>

int main()
{
    int quantidade, contador=1; 
    
    double calorias, totalCalorias=0;
    
    printf("digite a quantidade de alimentos/refeições igeridas: ");
    scanf("%d", &quantidade);
    
    do{
        
        printf ("\ndigite as calorias do alimento %d: ",contador);
        scanf("%lf", &calorias);
        totalCalorias = totalCalorias + calorias;
        contador++; 
        
    }while (contador<= quantidade);

    printf("foram ingeridas: %.2lf calorias.", totalCalorias);

    
    return 0;
}