#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    printf("\n%d", rand() % 61);
    printf("\n%d", rand() % 61);
    printf("\n%d", rand() % 61);
    printf("\n%d", rand() % 61);
    printf("\n%d", rand() % 61);
    printf("\n%d", rand() % 61);

    return 0;
}
