#include <stdio.h>
int main()
{
    int pi, pb;
    
    printf("Digite a quanttidade de gols da Inglaterra: ");
    scanf("%d", &pi);
    
    printf("Digite a quantidade de pontos do Brasil: ");
    scanf("%d",  &pb);
    
    if (pi > pb){
        printf ("\nInglaterra %d X Brasil %d ", pi, pb);
        printf ("\nInglaterra ganhou");
        
    }
    
    else if (pb == pi){
        printf ("\nInglaterra %d X Brasil %d ", pi, pb);
        printf ("\nEmpate");
    }
    else {
        
        printf ("\nInglaterra %d X Brasil %d ", pi, pb);
        printf ("\nBrasil amassou");
        
    }
    

    return 0;
}