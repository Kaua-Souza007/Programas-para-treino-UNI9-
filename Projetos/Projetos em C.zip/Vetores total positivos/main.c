#include <stdio.h>
#define TAM 10

int main()
{
    int numeros[TAM];
    int contador, contPositivos = 0;
    
    for (contador = 0; contador < TAM; contador++) {
        
        printf("\ndigite: ");
        scanf("%d", &numeros[contador]);
        
    }
    
    for (contador = 0; contador < TAM; contador++) {
        
        if (numeros[contador] > 0) {
            
            contPositivos++;
            
        }
    }
    
    printf("\n\nO total de numeros positivos é: %d", contPositivos);

    return 0;
}
